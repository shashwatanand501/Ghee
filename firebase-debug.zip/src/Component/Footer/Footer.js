import React from 'react';
import './Footer.css';
import Logo from '../../Assert/Round Sticker_page-0001 1.svg'; // Adjust the path as necessary
import ChatLogo from '../../Assert/Chat.svg'
import FB from '../../Assert/fb.svg'
import Instagram from '../../Assert/instagram.svg'

const Footer = () => {
  return (
    <footer>
      <div className="footer-container">
        <div className="footer-logo">
          <img src={Logo} alt="Logo" />
          <button className="footer-button"><img src={ChatLogo}></img>Drop a line</button>
        </div>
        <div className="footer-links">
          <div className="footer-column">
            <h4>INFO</h4>
            <ul>
              <li>Refund</li>
              <li>Privacy</li>
              <li>Terms of Service</li>
              <li>Shipping</li>
            </ul>
          </div>
          <div className="footer-column">
            <h4>ABOUT</h4>
            <ul>
              <li>About us</li>
            </ul>
          </div>
          <div className="footer-column">
            <h4>CONTACT US</h4>
            <ul>
              <li>XYZ</li>
              <li>91 891 989-11-91</li>
              <li>hello@logoipsum.com</li>
            </ul>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© 2024 — Copyright</p>
        <div className="footer-social">
          <a href="#"><img src={FB}></img></a>
          <a href="#"><img src={Instagram}></img></a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
