import React from 'react';
import './App.css';
import Header from './Component/Header/Header';
import Footer from './Component/Footer/Footer';
import AboutUs from './Screens/AboutUs/AboutUs';
import ShopNow from './Screens/ShopNow/ShopNow';
import Products from './Screens/Product/Product';
import FAQ from './Screens/Fnq/Fnq';

function App() {
  return (
    <div className="App">
      <Header />
      <main>
        <AboutUs />
        <ShopNow />
        <Products />
        <FAQ />
      </main>
      <Footer />
    </div>
  );
}

export default App;
