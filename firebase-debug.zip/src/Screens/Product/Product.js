import React from 'react';
import './Product.css'
import img from '../../Assert/Rectangle 8.png'
import star from '../../Assert/Star.svg'

const Products = () => {
  return (
    <section id="products">
      <div className="journey-container">
        <div className="journey-text">
          <h2>OUR JOURNEY</h2>
          <h1>From Humble Beginnings to Trusted Tradition</h1>
          <p>
            Our journey began in a small village where our family perfected the art of making ghee using traditional methods. What started as a cherished family recipe has grown into [Brand Name], a brand known for its purity and quality.
          </p>
          <p>
            From the beginning, we have focused on using the finest locally-sourced ingredients and time-honored techniques to create ghee that is rich in flavor and nutrients. Over the years, our commitment to excellence has earned us the trust of millions of customers.
          </p>
        </div>
        <div className="journey-image">
          <img src={img} alt="Our Journey" />
        </div>
      </div>
      <div className="testimonials-container">
        <div className="video-container">
          <iframe
            src="https://www.youtube.com/embed/LXb3EKWsInQ"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            title="YouTube Video"
          ></iframe>
        </div>
        <div className="testimonials-heading">
          <h3>TESTIMONIAL</h3>
          <h2>What Our Customers Are Saying</h2>
        </div>
        <div className="testimonials-cards">
          {Array(4).fill().map((_, i) => (
            <div className="testimonial-card" key={i}>
              <div className="testimonial-video-placeholder">
                <iframe
                  src="https://www.youtube.com/embed/LXb3EKWsInQ"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  title="YouTube Video"
                ></iframe>
              </div>

              <h4>PRIYA SHARMA</h4>
              <div className="rating">
                <span className="star">★</span> <p>4.73</p>
              </div>
              <p>
                I have been using [Brand Name] ghee for the past year, and I must say it’s the best I’ve ever had. The taste is rich and authentic.
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Products;
