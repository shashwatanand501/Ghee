import React from 'react';
import './AboutUs.css';
import star from '../../Assert/Star.svg';
import face from '../../Assert/team-fill.svg';
import leaf from '../../Assert/bxs-leaf 1.svg';
import PhoneImage from '../../Assert/image 5.svg';

const openWhatsApp = () => {
  const phoneNumber = '9810314220'; // WhatsApp number in international format without '+' or spaces
  const message = encodeURIComponent('Hello, I am interested in your product.');
  const url = `https://wa.me/${phoneNumber}?text=${message}`;
  window.open(url, '_blank');
};

const AboutUs = () => {
  return (
    <section id="about-us">
      <div className='aboutUs'>
        <div className='logo-text'>
          <img src={star} alt="Satisfaction Star" />
          <p>100%<br />Satisfaction</p>
        </div>
        <div className='logo-text'>
          <img src={face} alt="Happy Customers" />
          <p>5M+<br />Happy Customers</p>
        </div>
        <div className='logo-text'>
          <img src={leaf} alt="Pure and Natural" />
          <p>Pure<br />and Natural</p>
        </div>
      </div>
      <div className='about_us_article'>
        <div className='article'>
          <h2>Discover the Essence of Tradition in Every Jar</h2>
          <p>At [Brand Name], we are passionate about bringing you the purest and most authentic ghee, crafted with love and dedication. Our ghee is made using traditional methods passed down through generations, ensuring that each jar is rich in flavor, aroma, and nutritional benefits. Experience the unmatched quality and taste of our ghee, made from the finest ingredients to support your healthy lifestyle and culinary adventures.</p>
          <button className='primary-btn' onClick={openWhatsApp}>Shop Now</button>
        </div>
        <div>
          <img src={PhoneImage} alt="Phone" />
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
