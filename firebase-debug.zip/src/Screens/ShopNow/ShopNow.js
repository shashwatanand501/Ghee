import React from 'react';
import Card from '../../Component/Card/Card'
import Img from '../../Assert/Frame 122.svg'
import './ShopNow.css'
const ShopNow = () => {
  return (
    <section id="shop-now">
      <h2>Check our products</h2>
      <div className='card_container'>
        <Card
          image={Img}
          rating="4.73"
          description="Cow Ghee 300 g (Clarified 99.8% Milk Butter)"
          deliveryTime="Delivery in 10 working days"
          originalPrice="819"
          discountedPrice="599"
        />
        <Card
          image={Img}
          rating="4.80"
          description="Almonds 1 kg"
          deliveryTime="Delivery in 7 working days"
          originalPrice="1200"
          discountedPrice="999"
        />
      </div>

    </section>
  );
};

export default ShopNow;
